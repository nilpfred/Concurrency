from flask import Flask, render_template
from flask_socketio import SocketIO, join_room, leave_room, send, emit

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app)

@app.route('/')
def index():
    return render_template('index.html')

@socketio.on('join')
def on_join(data):
    room = data['room']
    join_room(room)
    emit('status', {'msg': f'{data["username"]} has joined the room.'}, room=room)

@socketio.on('move')
def on_move(data):
    room = data['room']
    move = data['move']
    emit('move', {'move': move}, room=room)

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000)
